// lib/services/database_service.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product_model.dart';
import '../models/order_model.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Collection References
  CollectionReference get productsRef => _firestore.collection('products');
  CollectionReference get ordersRef => _firestore.collection('orders');

  // -------------------- PRODUCTS --------------------

  // Fixes the Error in ProductProvider
  Future<List<ProductModel>> getAllProducts() async {
    try {
      final snapshot = await productsRef.get();
      return snapshot.docs.map((d) {
        final map = d.data() as Map<String, dynamic>;
        map['id'] = d.id;
        return ProductModel.fromMap(map);
      }).toList();
    } catch (e) {
      debugPrint('Error getAllProducts: $e');
      return [];
    }
  }

  Future<List<ProductModel>> getFarmerProducts(String farmerId) async {
    try {
      final snapshot = await productsRef.where('farmerId', isEqualTo: farmerId).get();
      return snapshot.docs.map((d) {
        final map = d.data() as Map<String, dynamic>;
        map['id'] = d.id;
        return ProductModel.fromMap(map);
      }).toList();
    } catch (e) {
      debugPrint('Error getFarmerProducts: $e');
      return [];
    }
  }

  Future<String?> addProduct(ProductModel product, List<String> imageUrls) async {
    try {
      final Map<String, dynamic> data = product.toMap();
      data['images'] = imageUrls;
      
      final docRef = product.id.isEmpty ? productsRef.doc() : productsRef.doc(product.id);
      data['id'] = docRef.id;
      
      await docRef.set(data);
      return docRef.id;
    } catch (e) { 
      return 'error: $e'; 
    }
  }

  // -------------------- ORDERS --------------------

  Future<String?> placeOrder(OrderModel order) async {
    try {
      final docRef = ordersRef.doc();
      final Map<String, dynamic> data = order.toMap();
      data['id'] = docRef.id;
      
      if (data['farmerId'] == null || data['retailerId'] == null) {
        return 'Missing IDs';
      }

      await docRef.set(data);
      return null; 
    } catch (e) {
      return e.toString();
    }
  }

  // Fixes the Error in OrderProvider
  Future<String?> updateOrderStatus(String orderId, String status) async {
    try {
      await ordersRef.doc(orderId).update({'status': status});
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<List<OrderModel>> getOrdersByField(String fieldName, String value) async {
    try {
      final snapshot = await ordersRef.where(fieldName, isEqualTo: value).get();
      return snapshot.docs.map((d) {
        final map = d.data() as Map<String, dynamic>;
        map['id'] = d.id;
        return OrderModel.fromMap(map);
      }).toList();
    } catch (e) {
      debugPrint('Error fetching orders: $e');
      return [];
    }
  }
}