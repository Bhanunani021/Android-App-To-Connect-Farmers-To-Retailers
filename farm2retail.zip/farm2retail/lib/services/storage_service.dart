import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // Upload product images
  Future<List<String>> uploadProductImages(String productId, List<String> imagePaths) async {
    // Return empty list if no images
    if (imagePaths.isEmpty) {
      return [];
    }
    
    List<String> imageUrls = [];

    try {
      for (int i = 0; i < imagePaths.length; i++) {
        String fileName = 'product_${productId}_$i.jpg';
        Reference ref = _storage.ref().child('products/$productId/$fileName');

        await ref.putFile(File(imagePaths[i]));
        String downloadUrl = await ref.getDownloadURL();
        imageUrls.add(downloadUrl);
      }
    } catch (e) {
      // If upload fails, return empty list
      return [];
    }

    return imageUrls;
  }
}
