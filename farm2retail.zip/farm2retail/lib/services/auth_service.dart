import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import 'package:flutter/foundation.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  AuthService() {
    // Ensuring persistence for Web
    _auth.setPersistence(Persistence.LOCAL);
  }

  Future<String?> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String userType,
    String? address,
  }) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      UserModel newUser = UserModel(
        uid: userCredential.user!.uid,
        email: email,
        name: name,
        phone: phone,
        userType: userType.toLowerCase().trim(), // Ensure lowercase
        address: address ?? '',
        createdAt: DateTime.now(),
      );

      await _firestore
          .collection('users')
          .doc(newUser.uid)
          .set(newUser.toMap());

      return null; 
    } catch (e) {
      return e.toString();
    }
  }

  Future<String?> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  Future<UserModel?> getUserData(String uid) async {
    try {
      // 🕵️ Debug: Check what ID we are looking for
      debugPrint("Searching Firestore for UID: $uid");
      
      DocumentSnapshot doc = await _firestore.collection('users').doc(uid).get();

      if (doc.exists && doc.data() != null) {
        debugPrint("User Document Found!");
        return UserModel.fromMap(doc.data() as Map<String, dynamic>);
      } else {
        // ⚠️ This is where your error triggers
        debugPrint("CRITICAL: No document found in 'users' collection for UID: $uid");
        return null;
      }
    } catch (e) {
      debugPrint("Firestore Read Error: $e");
      return null;
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }
}