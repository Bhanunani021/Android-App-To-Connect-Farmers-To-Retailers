// lib/providers/cart_provider.dart
import 'package:flutter/material.dart';
import '../models/cart_item_model.dart';

class CartProvider with ChangeNotifier {
  final Map<String, CartItem> _items = {};

  Map<String, CartItem> get items => {..._items};

  int get itemCount => _items.length;

  double get totalAmount {
    double total = 0.0;
    _items.forEach((key, cartItem) {
      total += cartItem.totalPrice;
    });
    return total;
  }

  void addItem(
    String productId,
    String productName,
    String farmerId,
    String farmerName,
    double price,
    String unit,
    double quantity,
    String category,
  ) {
    debugPrint(
        'CartProvider.addItem: productId=$productId farmerId=$farmerId farmerName=$farmerName');

    if (_items.containsKey(productId)) {
      _items[productId]!.quantity += quantity;
    } else {
      _items[productId] = CartItem(
        productId: productId,
        productName: productName,
        farmerId: farmerId,
        farmerName: farmerName,
        price: price,
        unit: unit,
        quantity: quantity,
        category: category,
      );
    }
    notifyListeners();
  }

  void removeItem(String productId) {
    _items.remove(productId);
    notifyListeners();
  }

  void updateQuantity(String productId, double quantity) {
    if (_items.containsKey(productId)) {
      _items[productId]!.quantity = quantity;
      notifyListeners();
    }
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}

class CartItem {
  final String productId;
  final String productName;
  final String farmerId;
  final String farmerName;
  final double price;
  final String unit;
  double quantity;
  final String category;

  CartItem({
    required this.productId,
    required this.productName,
    required this.farmerId,
    required this.farmerName,
    required this.price,
    required this.unit,
    required this.quantity,
    required this.category,
  });

  double get totalPrice => price * quantity;
}
