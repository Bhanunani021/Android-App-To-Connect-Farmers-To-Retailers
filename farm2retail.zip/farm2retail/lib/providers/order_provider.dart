import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/order_model.dart';

class OrderProvider with ChangeNotifier {
  List<OrderModel> _orders = [];
  List<OrderModel> _farmerOrders = [];
  bool _isLoading = false;

  List<OrderModel> get orders => _orders;
  List<OrderModel> get farmerOrders => _farmerOrders;
  bool get isLoading => _isLoading;

  // ✅ FIXED: Use addPostFrameCallback to avoid build-phase notify
  Future<void> _loadRetailerOrdersSafe(String userId) async {
    if (!mounted) return;
    await loadRetailerOrders(userId);
  }

  Future<void> _loadFarmerOrdersSafe(String userId) async {
    if (!mounted) return;
    await loadFarmerOrders(userId);
  }

  // RETAILER ORDERS
  Future<void> loadRetailerOrders(String userId) async {
    try {
      _isLoading = true;
      
      final snapshot = await FirebaseFirestore.instance
          .collection('orders')
          .where('retailerId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .limit(50)
          .get();

      _orders = snapshot.docs.map((doc) => 
        OrderModel.fromMap({...doc.data(), 'id': doc.id})).toList();
      
      debugPrint("✅ Retailer loaded ${_orders.length} orders");
    } catch (e) {
      debugPrint("❌ Retailer orders error: $e");
      _orders = [];
    } finally {
      _isLoading = false;
      if (mounted) notifyListeners();
    }
  }

  // FARMER ORDERS
  Future<void> loadFarmerOrders(String farmerId) async {
    try {
      _isLoading = true;
      
      final snapshot = await FirebaseFirestore.instance
          .collection('orders')
          .where('farmerId', isEqualTo: farmerId)
          .orderBy('createdAt', descending: true)
          .limit(50)
          .get();

      _farmerOrders = snapshot.docs.map((doc) => 
        OrderModel.fromMap({...doc.data(), 'id': doc.id})).toList();
      
      debugPrint("✅ Farmer loaded ${_farmerOrders.length} orders");
    } catch (e) {
      debugPrint("❌ Farmer orders error: $e");
      _farmerOrders = [];
    } finally {
      _isLoading = false;
      if (mounted) notifyListeners();
    }
  }

  // ✅ SIMPLIFIED: NO STOCK CHANGES - Just create order
  Future<String?> placeOrder(OrderModel order) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return 'User not authenticated';

      // VALIDATE productId
      if (order.productId.isEmpty) {
        return 'Invalid product ID';
      }

      // ✅ JUST CREATE ORDER - NO STOCK REDUCTION
      final orderData = {
        'farmerId': order.farmerId,
        'retailerId': user.uid,
        'productId': order.productId,
        'productName': order.productName,
        'quantity': order.quantity,
        'totalPrice': order.totalPrice,
        'status': 'pending',
        'customerName': order.customerName ?? 'Retailer',
        'customerPhone': order.customerPhone ?? '',
        'customerAddress': order.customerAddress ?? '',
        'createdAt': FieldValue.serverTimestamp(),
      };
      
      await FirebaseFirestore.instance.collection('orders').add(orderData);
      debugPrint("✅ Order created: ${order.productName} x${order.quantity}");
      
      return null; // Success
    } catch (e) {
      debugPrint("❌ Order error: $e");
      return e.toString();
    }
  }

  // Update order status (farmer)
  Future<String?> updateOrderStatus(String orderId, String newStatus) async {
    try {
      await FirebaseFirestore.instance.collection('orders').doc(orderId).update({
        'status': newStatus,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      // Refresh orders
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await loadFarmerOrders(user.uid);
      }
      
      debugPrint("✅ Status updated: $newStatus");
      return null;
    } catch (e) {
      debugPrint("❌ Status update error: $e");
      return e.toString();
    }
  }

  bool get mounted => true; // Provider workaround
}
