import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AppAuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  UserModel? _currentUser;
  bool _isLoading = true;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;

  AppAuthProvider() {
    _init();
  }

  void _init() {
    _firebaseAuth.authStateChanges().listen((User? user) async {
      debugPrint("🔄 Auth state changed. User: ${user?.email ?? 'null'}");
      
      if (user == null) {
        // ✅ CRITICAL: Properly reset state when no user
        _currentUser = null;
        _isLoading = false;
        notifyListeners();
      } else {
        await loadCurrentUser();
      }
    });

    // ✅ Initialize current state immediately
   // loadCurrentUser();
  }

  // --- SIGN UP METHOD ---
  Future<String?> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String userType,
    String? address,
  }) async {
    try {
      _isLoading = true;
      notifyListeners();

      String? error = await _authService.signUp(
        email: email,
        password: password,
        name: name,
        phone: phone,
        userType: userType,
        address: address,
      );

      if (error == null) {
        await loadCurrentUser();
        return null;
      }
      return error;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- SIGN IN ---
  Future<String?> signIn(String email, String password) async {
    try {
      _isLoading = true;
      notifyListeners();

      String? error = await _authService.signIn(email, password);
      if (error == null) {
        await loadCurrentUser();
        return null;
      }
      return error;
    } catch (e) {
      return e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- LOAD PROFILE ---
  Future<void> loadCurrentUser() async {
    try {
      _isLoading = true;
      notifyListeners();
      
      final user = _firebaseAuth.currentUser;
      if (user != null) {
        _currentUser = await _authService.getUserData(user.uid);
        debugPrint("✅ User loaded: ${_currentUser?.name} (${_currentUser?.userType})");
      } else {
        _currentUser = null;
      }
    } catch (e) {
      debugPrint("❌ Error in loadCurrentUser: $e");
      _currentUser = null;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- FIXED SIGN OUT (CRITICAL FIX) ---
  Future<void> signOut() async {
    try {
      debugPrint("🔓 Starting logout...");
      _isLoading = true;
      notifyListeners();
      
      // 1. Clear Firestore cache immediately
      await _authService.signOut();
      
      // 2. Force auth state to null (triggers listener)
      await _firebaseAuth.signOut();
      
      // 3. Clear local state (belt + suspenders)
      _currentUser = null;
      
      debugPrint("✅ Logout complete!");
    } catch (e) {
      debugPrint("❌ Logout error: $e");
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
