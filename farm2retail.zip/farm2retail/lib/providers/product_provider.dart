import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../models/product_model.dart';

class ProductProvider with ChangeNotifier {
  List<ProductModel> _products = [];
  bool _isLoading = false;

  List<ProductModel> get products => _products;
  bool get isLoading => _isLoading;

  Future<void> loadProducts({bool isFarmer = false}) async {
    try {
      _isLoading = true;
      notifyListeners();

      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        _products = [];
        _isLoading = false;
        notifyListeners();
        return;
      }

      Query<Map<String, dynamic>> query = 
          FirebaseFirestore.instance.collection('products');

      if (isFarmer) {
        query = query.where('farmerId', isEqualTo: user.uid);
        debugPrint("🌾 Farmer loading OWN products: ${user.uid}");
      } else {
        debugPrint("🛒 Retailer loading ALL products");
      }

      final snapshot = await query.orderBy('createdAt', descending: true).get();
      _products = snapshot.docs
          .map((doc) => ProductModel.fromMap(doc.data()))
          .toList();

      debugPrint("✅ Loaded ${_products.length} products total");
    } catch (e) {
      debugPrint("❌ Products error: $e");
      _products = [];
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ✅ SIMPLIFIED - NO Uint8List, NO setters - JUST works
  Future<String?> addProduct(Map<String, dynamic> productData) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return 'User not authenticated';

      final data = {
        ...productData,
        'farmerId': user.uid,
        'farmerName': user.displayName ?? 'Farmer',
        'createdAt': FieldValue.serverTimestamp(),
      };
      
      await FirebaseFirestore.instance.collection('products').add(data);
      debugPrint("✅ Product added successfully");
      return null;
    } catch (e) {
      debugPrint("❌ Add product error: $e");
      return e.toString();
    }
  }
}
