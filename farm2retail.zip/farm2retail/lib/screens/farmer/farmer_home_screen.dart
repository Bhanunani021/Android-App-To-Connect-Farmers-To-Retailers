import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/auth_provider.dart';
import '../../providers/product_provider.dart';
import '../../models/product_model.dart';
import '../auth/login_screen.dart';
import 'add_product_screen.dart';
import 'farmer_orders_screen.dart';

class FarmerHomeScreen extends StatefulWidget {
  const FarmerHomeScreen({super.key});

  @override
  State<FarmerHomeScreen> createState() => _FarmerHomeScreenState();
}

class _FarmerHomeScreenState extends State<FarmerHomeScreen> {
  List<ProductModel> _myProducts = [];
  bool _isLoading = true;
  bool _initialLoadDone = false;
  bool _isLoggingOut = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadMyProducts());
  }

  bool _isUserFarmer({bool listen = false}) {
    final authProvider = Provider.of<AppAuthProvider>(context, listen: listen);
    final user = authProvider.currentUser;
    if (user == null) return false;

    final ut = (user.userType ?? '').toString().trim().toLowerCase();
    final role = (user.role ?? '').toString().trim().toLowerCase();
    final isFarmerFlag = (user.isFarmer == true);

    return ut == 'farmer' || role == 'farmer' || isFarmerFlag;
  }

  Future<void> _loadMyProducts() async {
    setState(() => _isLoading = true);

    final authProvider = Provider.of<AppAuthProvider>(context, listen: false);
    final productProvider = Provider.of<ProductProvider>(context, listen: false);

    final user = authProvider.currentUser;
    if (user == null) {
      if (mounted) {
        setState(() {
          _myProducts = [];
          _isLoading = false;
          _initialLoadDone = true;
        });
      }
      return;
    }

    try {
      debugPrint('DEBUG: Loading products for farmer: ${user.uid} (userType="${user.userType}", role="${user.role}", isFarmer=${user.isFarmer})');

      await productProvider.loadProducts(isFarmer: true);
      _myProducts = productProvider.products;

      debugPrint('DEBUG: Loaded ${_myProducts.length} products for ${user.uid}');

      if (mounted) {
        setState(() {
          _isLoading = false;
          _initialLoadDone = true;
        });
      }
    } catch (e, st) {
      debugPrint('ERROR loading farmer products: $e\n$st');
      if (mounted) {
        setState(() {
          _myProducts = [];
          _isLoading = false;
          _initialLoadDone = true;
        });
      }
    }
  }

  Future<void> _handleLogout() async {
    if (_isLoggingOut) return;
    _isLoggingOut = true;
    final authProvider = Provider.of<AppAuthProvider>(context, listen: false);
    await authProvider.signOut();
    _isLoggingOut = false;
  }

  Future<void> _openAddProduct() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AddProductScreen()),
    );
    await _loadMyProducts();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AppAuthProvider>(context);
    final user = authProvider.currentUser;
    final bool isFarmer = _isUserFarmer(listen: true);

    debugPrint('DEBUG USER -> uid: ${user?.uid} userType:"${user?.userType}" role:"${user?.role}" isFarmer:${user?.isFarmer}');

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Products'),
        backgroundColor: Colors.green[700],
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_bag),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const FarmerOrdersScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadMyProducts,
            tooltip: 'Refresh products',
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _isLoggingOut ? null : _handleLogout,
          ),
          if (isFarmer)
            IconButton(
              icon: const Icon(Icons.add),
              tooltip: 'Add product',
              onPressed: _openAddProduct,
            ),
        ],
      ),
      body: _isLoading && !_initialLoadDone
          ? const Center(child: CircularProgressIndicator())
          : _myProducts.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.inventory_2_outlined, size: 100, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      const Text('No products yet', style: TextStyle(fontSize: 18, color: Colors.grey)),
                      const SizedBox(height: 8),
                      const Text('Tap + to add your first product', style: TextStyle(color: Colors.grey)),
                      const SizedBox(height: 16),
                      if (isFarmer)
                        ElevatedButton.icon(
                          onPressed: _openAddProduct,
                          icon: const Icon(Icons.add),
                          label: const Text('Add your first product'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green[700]),
                        ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadMyProducts,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _myProducts.length,
                    itemBuilder: (context, index) {
                      final product = _myProducts[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.grey[200],
                                ),
                                child: product.images.isNotEmpty
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: Image.network(
                                          product.images.first,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Icon(Icons.image_not_supported, color: Colors.grey[400]),
                                        ),
                                      )
                                    : Icon(Icons.image, color: Colors.grey[400]),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      product.productName ?? 'Unnamed product',
                                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      product.category ?? '',
                                      style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '₹${(product.price ?? 0).toStringAsFixed(2)}/${product.unit ?? ''}',
                                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.green[700]),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Available: ${product.quantity ?? 0} ${product.unit ?? ''}',
                                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: (product.isAvailable ?? false) ? Colors.green[50] : Colors.red[50],
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  (product.isAvailable ?? false) ? 'Active' : 'Inactive',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: (product.isAvailable ?? false) ? Colors.green[700] : Colors.red[700],
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: isFarmer
          ? FloatingActionButton.extended(
              onPressed: _openAddProduct,
              backgroundColor: Colors.green[700],
              icon: const Icon(Icons.add),
              label: const Text('Add Product'),
            )
          : null,
    );
  }
}
