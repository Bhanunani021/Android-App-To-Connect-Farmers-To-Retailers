import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:farm2retail/models/product_model.dart';
import 'package:farm2retail/providers/product_provider.dart';
import 'package:farm2retail/providers/auth_provider.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _categoryCtrl = TextEditingController();
  final TextEditingController _priceCtrl = TextEditingController();
  final TextEditingController _unitCtrl = TextEditingController();
  final TextEditingController _quantityCtrl = TextEditingController();
  final TextEditingController _descCtrl = TextEditingController();

  XFile? _pickedImage;
  final ImagePicker _picker = ImagePicker();

  bool _isSubmitting = false;
  double _uploadProgress = 0.0;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _categoryCtrl.dispose();
    _priceCtrl.dispose();
    _unitCtrl.dispose();
    _quantityCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  void _resetForm() {
    _nameCtrl.clear();
    _categoryCtrl.clear();
    _priceCtrl.clear();
    _unitCtrl.clear();
    _quantityCtrl.clear();
    _descCtrl.clear();
    _pickedImage = null;
  }

  Future<void> _pickImage() async {
    debugPrint('TRACE: _pickImage() ENTER');
    try {
      final XFile? xfile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (xfile != null) {
        setState(() => _pickedImage = xfile);
        debugPrint('TRACE: picked image path=${xfile.path}');
      } else {
        debugPrint('TRACE: pickImage returned null (user cancelled)');
      }
    } catch (e, st) {
      debugPrint('ERROR: _pickImage exception -> $e\n$st');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to pick image: $e')));
      }
    } finally {
      debugPrint('TRACE: _pickImage() EXIT');
    }
  }

  Future<void> _submit() async {
    debugPrint('TRACE: _submit() ENTER');

    final authProvider = Provider.of<AppAuthProvider>(context, listen: false);
    final productProvider = Provider.of<ProductProvider>(context, listen: false);

    final valid = _formKey.currentState?.validate() ?? false;
    debugPrint('TRACE: form validation result = $valid');
    if (!valid) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill all required fields')),
        );
      }
      return;
    }

    if (_pickedImage == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please select an image')),
        );
      }
      return;
    }

    final firebaseUser = FirebaseAuth.instance.currentUser;
    final String? farmerId = firebaseUser?.uid;
    debugPrint('TRACE: firebaseUser=${firebaseUser?.uid}, providerUser=${authProvider.currentUser?.uid}, farmerIdUsed=$farmerId');

    if (farmerId == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('User not signed in')),
        );
      }
      return;
    }

    setState(() {
      _isSubmitting = true;
      _uploadProgress = 0.0;
    });

    try {
      debugPrint('TRACE: reading bytes from picked image');
      final Uint8List imgBytes = await _pickedImage!.readAsBytes();
      debugPrint('TRACE: image bytes length=${imgBytes.lengthInBytes}');

      final productData = {
        'productName': _nameCtrl.text.trim(),
        'category': _categoryCtrl.text.trim(),
        'price': double.tryParse(_priceCtrl.text.trim()) ?? 0.0,
        'unit': _unitCtrl.text.trim().isEmpty ? 'kg' : _unitCtrl.text.trim(),
        'quantity': double.tryParse(_quantityCtrl.text.trim()) ?? 0.0,
        'description': _descCtrl.text.trim(),
        'images': [], // Images handled separately
        'isAvailable': true,
        'farmerId': farmerId,
        'farmerName': authProvider.currentUser?.name ?? 'Farmer',
      };

      debugPrint('TRACE UI -> calling productProvider.addProduct (about to await)');
      final result = await productProvider.addProduct(productData);

      debugPrint('TRACE UI -> productProvider.addProduct returned -> $result');

      // ✅ FIXED LOGIC: null = SUCCESS
      if (result == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ Product added successfully!'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 2),
            ),
          );
          _resetForm();
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('❌ Failed to add product: $result'), backgroundColor: Colors.red),
          );
        }
      }
    } catch (e, st) {
      debugPrint('ERROR: _submit exception -> $e\n$st');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
          _uploadProgress = 0.0;
        });
      }
      debugPrint('TRACE: _submit() EXIT');
    }
  }

  Widget _buildImagePreview() {
    if (_pickedImage == null) {
      return Container(
        width: 110,
        height: 110,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: const Icon(Icons.photo_library, size: 36, color: Colors.grey),
      );
    }

    return FutureBuilder<Uint8List>(
      future: _pickedImage!.readAsBytes(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.memory(
              snapshot.data!,
              width: 110,
              height: 110,
              fit: BoxFit.cover,
            ),
          );
        }
        return Container(
          width: 110,
          height: 110,
          color: Colors.grey.shade200,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add New Product'),
        backgroundColor: Colors.green[700],
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              InkWell(
                onTap: _pickImage,
                child: Container(
                  height: 120,
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    children: [
                      _buildImagePreview(),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _pickedImage != null ? 'Tap to change image' : 'Tap to select product image',
                          style: TextStyle(color: Colors.grey.shade700),
                        ),
                      ),
                      if (_isSubmitting)
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: SizedBox(
                            width: 48,
                            child: LinearProgressIndicator(value: _uploadProgress),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller: _nameCtrl,
                      decoration: const InputDecoration(labelText: 'Product name'),
                      validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter product name' : null,
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _categoryCtrl,
                      decoration: const InputDecoration(labelText: 'Category (e.g. Vegetables)'),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _priceCtrl,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            decoration: const InputDecoration(labelText: 'Price (per unit)'),
                            validator: (v) => (v == null || double.tryParse(v.trim()) == null) ? 'Enter valid price' : null,
                          ),
                        ),
                        const SizedBox(width: 12),
                        SizedBox(
                          width: 120,
                          child: TextFormField(
                            controller: _unitCtrl,
                            decoration: const InputDecoration(labelText: 'Unit (kg/ltr/pcs)'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _quantityCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'Available quantity'),
                      validator: (v) => (v == null || double.tryParse(v.trim()) == null) ? 'Enter valid quantity' : null,
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _descCtrl,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: 'Short description'),
                    ),
                    const SizedBox(height: 18),
                    _isSubmitting
                        ? const CircularProgressIndicator()
                        : SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: _submit,
                              icon: const Icon(Icons.add_business),
                              label: const Text('Add Product'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[700],
                                padding: const EdgeInsets.symmetric(vertical: 14),
                              ),
                            ),
                          ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
