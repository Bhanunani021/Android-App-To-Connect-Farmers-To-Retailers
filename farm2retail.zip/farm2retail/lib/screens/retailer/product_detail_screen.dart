import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/cart_provider.dart';
import '../../models/product_model.dart';

class ProductDetailScreen extends StatefulWidget {
  final ProductModel product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  double _quantity = 1.0;
  late TextEditingController _quantityController;

  @override
  void initState() {
    super.initState();
    _quantityController = TextEditingController(text: '1.0');
  }

  @override
  void dispose() {
    _quantityController.dispose();
    super.dispose();
  }

  void _updateQuantity(String value) {
    final newQty = double.tryParse(value) ?? 0.0;
    setState(() {
      _quantity = newQty.clamp(0.1, widget.product.quantity);
      _quantityController.text = _quantity.toStringAsFixed(1);
    });
  }

  @override
  Widget build(BuildContext context) {
    final safeProductId = widget.product.id.isNotEmpty 
        ? widget.product.id 
        : '${widget.product.productName}_${DateTime.now().millisecondsSinceEpoch}';

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.product.productName),
        backgroundColor: Colors.green[700],
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Product Image
            Container(
              height: 250,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey[200],
              ),
              child: widget.product.images.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        widget.product.images.first,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          height: 250,
                          child: const Icon(
                            Icons.image_not_supported,
                            size: 64,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    )
                  : Container(
                      height: 250,
                      child: const Icon(Icons.image, size: 64, color: Colors.grey),
                    ),
            ),
            
            const SizedBox(height: 16),
            
            // Product Name
            Text(
              widget.product.productName,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            
            const SizedBox(height: 8),
            
            // Category & Farmer
            Row(
              children: [
                Chip(
                  label: Text(widget.product.category),
                  backgroundColor: Colors.green[100],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'By ${widget.product.farmerName}',
                    style: TextStyle(color: Colors.grey[600], fontSize: 14),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Price & Stock Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Price', style: TextStyle(fontSize: 16)),
                        Text(
                          '₹${widget.product.price.toStringAsFixed(2)} / ${widget.product.unit}',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Stock', style: TextStyle(fontSize: 16)),
                        Text(
                          '${widget.product.quantity.toStringAsFixed(0)} ${widget.product.unit}',
                          style: TextStyle(
                            fontSize: 16,
                            color: widget.product.isAvailable ? Colors.green : Colors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 20),
            
            // ✅ MANUAL QUANTITY INPUT FIELD
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Quantity',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _quantityController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: '${widget.product.unit}',
                        hintText: 'Type quantity (e.g. 2.5)',
                        prefixIcon: const Icon(Icons.scale),
                        border: const OutlineInputBorder(),
                        suffixText: 'Max: ${widget.product.quantity.toStringAsFixed(0)}',
                        suffixStyle: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      onChanged: _updateQuantity,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Available: ${widget.product.quantity.toStringAsFixed(0)} ${widget.product.unit}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            // Description
            if (widget.product.description?.isNotEmpty ?? false) ...[
              const Text(
                'Description', 
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
              ),
              const SizedBox(height: 8),
              Text(
                widget.product.description!,
                style: TextStyle(color: Colors.grey[700]),
              ),
              const SizedBox(height: 24),
            ],
            
            // ✅ ADD TO CART WITH TYPED QUANTITY
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: () {
                  final cart = Provider.of<CartProvider>(context, listen: false);
                  
                  cart.addItem(
                    safeProductId,
                    widget.product.productName,
                    widget.product.farmerId ?? 'unknown',
                    widget.product.farmerName ?? 'Farmer',
                    widget.product.price,
                    widget.product.unit ?? 'kg',
                    _quantity,  // ✅ USER TYPED QUANTITY
                    widget.product.category ?? '',
                  );
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        '✅ Added ${_quantity.toStringAsFixed(1)} ${widget.product.unit} of ${widget.product.productName} to cart!'
                      ),
                      backgroundColor: Colors.green,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                  
                  Navigator.pop(context); // Return to products
                },
                icon: const Icon(Icons.shopping_cart),
                label: Text(
                  'Add ${_quantity.toStringAsFixed(1)} ${widget.product.unit} to Cart',
                  style: const TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green[700],
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
