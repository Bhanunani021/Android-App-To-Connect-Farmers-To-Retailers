// lib/models/order_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class OrderModel {
  final String id;
  final String farmerId;
  final String retailerId;
  final String productId;
  final String productName;
  final double quantity;
  final double totalPrice;
  final String status; // 'pending', 'accepted', 'rejected', 'completed'
  final DateTime createdAt;

  final String customerName;
  final String customerPhone;
  final String customerAddress;

  OrderModel({
    required this.id,
    required this.farmerId,
    required this.retailerId,
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.totalPrice,
    required this.status,
    required this.createdAt,
    required this.customerName,
    required this.customerPhone,
    required this.customerAddress,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'farmerId': farmerId,
      'retailerId': retailerId,
      'productId': productId,
      'productName': productName,
      'quantity': quantity,
      'totalPrice': totalPrice,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
      'customerName': customerName,
      'customerPhone': customerPhone,
      'customerAddress': customerAddress,
    };
  }

  factory OrderModel.fromMap(Map<String, dynamic> map) {
    // 🔥 SAFE DATETIME PARSING: Prevents crashes from malformed data
    DateTime parsedDate;
    var dateData = map['createdAt'];
    
    if (dateData is Timestamp) {
      parsedDate = dateData.toDate();
    } else if (dateData is String) {
      // tryParse returns null instead of throwing an error if the string is bad
      parsedDate = DateTime.tryParse(dateData) ?? DateTime.now();
    } else {
      parsedDate = DateTime.now(); 
    }

    return OrderModel(
      id: map['id'] ?? '',
      farmerId: map['farmerId'] ?? '',
      retailerId: map['retailerId'] ?? '',
      productId: map['productId'] ?? '',
      productName: map['productName'] ?? '',
      // Ensure we don't crash if an int is passed instead of a double
      quantity: (map['quantity'] ?? 0.0).toDouble(),
      totalPrice: (map['totalPrice'] ?? 0.0).toDouble(),
      status: map['status'] ?? 'pending',
      createdAt: parsedDate,
      customerName: map['customerName'] ?? '',
      customerPhone: map['customerPhone'] ?? '',
      customerAddress: map['customerAddress'] ?? '',
    );
  }
}