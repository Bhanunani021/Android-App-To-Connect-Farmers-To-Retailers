class CartItem {
  final String productId;
  final String productName;
  final String farmerId;
  final String farmerName;
  final double price;
  final String unit;
  double quantity;
  final String category;

  CartItem({
    required this.productId,
    required this.productName,
    required this.farmerId,
    required this.farmerName,
    required this.price,
    required this.unit,
    required this.quantity,
    required this.category,
  });

  double get totalPrice => price * quantity;
}
