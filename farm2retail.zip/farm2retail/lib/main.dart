import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'package:farm2retail/providers/auth_provider.dart';
import 'package:farm2retail/providers/product_provider.dart';
import 'package:farm2retail/providers/order_provider.dart';
import 'package:farm2retail/providers/cart_provider.dart';

import 'package:farm2retail/screens/auth/login_screen.dart';
import 'package:farm2retail/screens/farmer/farmer_home_screen.dart';
import 'package:farm2retail/screens/retailer/retailer_home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppAuthProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
        ChangeNotifierProvider(create: (_) => OrderProvider()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
      ],
      child: MaterialApp(
        title: 'Farm2Retail',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.green,
          useMaterial3: true,
        ),
        home: const AuthWrapper(),
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    // We use context.watch to make sure this widget rebuilds 
    // the MOMENT the AuthProvider data changes.
    final auth = context.watch<AppAuthProvider>();

    // 1. If the provider is still fetching data from Firebase/Firestore
    if (auth.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator(color: Colors.green)),
      );
    }

    // 2. Check if we have a valid user object from Firestore
    final user = auth.currentUser;

    if (user == null) {
      // No user in Firestore or Auth session is empty -> Show Login
      return const LoginScreen();
    }

    // 3. We have a user! Now route strictly based on the userType string.
    // We use .toLowerCase() and .trim() to catch any database typos.
    final String role = user.userType.toLowerCase().trim();

    if (role == 'farmer') {
      debugPrint("AuthWrapper: Routing to Farmer Dashboard");
      return const FarmerHomeScreen();
    } else if (role == 'retailer') {
      debugPrint("AuthWrapper: Routing to Retailer Dashboard");
      return const RetailerHomeScreen();
    } else {
      // Fallback for safety: if type is unknown, go to Login and print error
      debugPrint("AuthWrapper ERROR: Unknown user role found: $role");
      return const LoginScreen();
    }
  }
}