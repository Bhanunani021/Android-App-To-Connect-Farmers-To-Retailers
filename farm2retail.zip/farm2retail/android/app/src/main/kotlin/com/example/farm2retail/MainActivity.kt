package com.example.farm2retail

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
